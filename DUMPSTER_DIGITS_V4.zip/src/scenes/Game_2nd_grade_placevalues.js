import {Trash} from  '../GameObjects/Trash.js'; //can copy the path
import {TrashCan} from '../GameObjects/TrashCan.js';

export class Game_2nd_grade_placevalues extends Phaser.Scene {
    constructor() {
        super('Game');

    }
/*Frame Dimensions: width: 1536,
                    height: 793*/

    create() {

 // this.add.image(90, 50, 'camp').setScale(3);
      for(let i = 1; i<= 7; i++){
        const y = 50 + (i-1) * 100;

        this['campGroundRow${i}'] = this.add.group({
          key: 'camp',
          repeat: 11,
          setXY: {x: 90, y: y, stepX: 180},
          setScale: {x:3, y:6}
        });
      }


    function placeValueProblems() {
      const onesProblems = [];
      const tensProblems = [];
      const hundredsProblems = [];
      const allProblems = [];

      for(let n = 1; n <= 999; n++){
        const ones = n % 10;
        const tens = Math.floor(n/10) % 10;
        const hundreds = Math.floor(n/100);

        onesProblems.push({
          answer: `${n}`,
          question: `${ones} in 1s place`
        });

        tensProblems.push({
          answer:`${n}`,
          question: `${tens} in 10s place`
        });

        if(hundreds !== 0){
        hundredsProblems.push({
          answer: `${n}`,
          question: `${hundreds} in 100s place`
        });
        };
      }
      for(let n = 1; n <= 100; n++)
      {
        allProblems.push(onesProblems[n]);
      }
      for(let n = 1; n <= 100; n++)
      {
        allProblems.push(tensProblems[n]);
      }
      for(let n = 1; n <= 100; n++)
      {
        allProblems.push(hundredsProblems[n]);
      }

      return allProblems;
    }


    this.problemsPlaceValues = placeValueProblems();
   
      this.problem1 = Phaser.Utils.Array.GetRandom(this.problemsPlaceValues);
          Phaser.Utils.Array.Remove(this.problemsPlaceValues, this.problem1);
      this.problem2 = Phaser.Utils.Array.GetRandom(this.problemsPlaceValues);
          Phaser.Utils.Array.Remove(this.problemsPlaceValues, this.problem2);
      this.problem3 = Phaser.Utils.Array.GetRandom(this.problemsPlaceValues);
          Phaser.Utils.Array.Remove(this.problemsPlaceValues, this.problem3);
      this.problem4 = Phaser.Utils.Array.GetRandom(this.problemsPlaceValues);
          Phaser.Utils.Array.Remove(this.problemsPlaceValues, this.problem4);
      this.problem5 = Phaser.Utils.Array.GetRandom(this.problemsPlaceValues);
          Phaser.Utils.Array.Remove(this.problemsPlaceValues, this.problem5);


      //createes and array of randomized problems
      this.possibleQuestions = [
        this.problem1,
        this.problem2,
        this.problem3,
        this.problem4,
        this.problem5
      ]

      //each question is one of the random problems
      this.question1 = Phaser.Utils.Array.GetRandom(this.possibleQuestions);
        Phaser.Utils.Array.Remove(this.possibleQuestions, this.question1);

      this.question2 = Phaser.Utils.Array.GetRandom(this.possibleQuestions);
        Phaser.Utils.Array.Remove(this.possibleQuestions, this.question2);

      this.question3 = Phaser.Utils.Array.GetRandom(this.possibleQuestions);
        Phaser.Utils.Array.Remove(this.possibleQuestions, this.question3);

      this.question4 = Phaser.Utils.Array.GetRandom(this.possibleQuestions);
        Phaser.Utils.Array.Remove(this.possibleQuestions, this.question4);

      this.question5 = Phaser.Utils.Array.GetRandom(this.possibleQuestions);
        Phaser.Utils.Array.Remove(this.possibleQuestions, this.question5); 

      // creates an array of randomized answers
      this.possibleAnswers = [
        this.problem1,
        this.problem2,
        this.problem3,
        this.problem4,
        this.problem5
      ]

      //assign a random answer to one of the answer#

      //WARNING!!!! it is possible for two number both to have x in the same place
      //resulting in two questions that look the same but are foced into diffrent answers
      this.answer1 = Phaser.Utils.Array.GetRandom(this.possibleAnswers);
        Phaser.Utils.Array.Remove(this.possibleAnswers, this.answer1);

      this.answer2 = Phaser.Utils.Array.GetRandom(this.possibleAnswers);
        Phaser.Utils.Array.Remove(this.possibleAnswers, this.answer2);

      this.answer3 = Phaser.Utils.Array.GetRandom(this.possibleAnswers);
        Phaser.Utils.Array.Remove(this.possibleAnswers, this.answer3);

      this.answer4 = Phaser.Utils.Array.GetRandom(this.possibleAnswers);
        Phaser.Utils.Array.Remove(this.possibleAnswers, this.answer4);

      this.answer5 = Phaser.Utils.Array.GetRandom(this.possibleAnswers);
        Phaser.Utils.Array.Remove(this.possibleAnswers, this.answer5);
      

// creates trashcans and their individual answers
      this.trashCan1 = new TrashCan(this, 100, 700, this.answer1).setScale(1);
      this.trashCan2 = new TrashCan(this, 440, 700, this.answer2).setScale(1);
      this.trashCan3 = new TrashCan(this, 740, 700, this.answer3).setScale(1);
      this.trashCan4 = new TrashCan(this, 1040, 700, this.answer4).setScale(1);
      this.trashCan5 = new TrashCan(this, 1340, 700, this.answer5).setScale(1);

// Createse trash and their individual questions
     this.trash1 = new Trash(this, 550, 280, this.question1);
      this.trash2 = new Trash(this, 650, 400, this.question2);
      this.trash3 = new Trash(this, 750, 280, this.question3);
      this.trash4 = new Trash(this, 850, 400, this.question4);
      this.trash5 = new Trash(this, 950, 280, this.question5);
      //this.replacementTrash = new Trash;

      this.trashCan1.setTextScale(20);//Set in pixels
      this.trashCan2.setTextScale(20);
      this.trashCan3.setTextScale(20);
      this.trashCan4.setTextScale(20);
      this.trashCan5.setTextScale(20);

        this.numGuessesPerAnswer = [
          {guessedAnswer: this.trash1, numGuess: 0},
          {guessedAnswer: this.trash2, numGuess: 0},
          {guessedAnswer: this.trash3, numGuess: 0},
          {guessedAnswer: this.trash4, numGuess: 0},
          {guessedAnswer: this.trash5, numGuess: 0}
        ];
        
 //////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
      this.numCorrect = 0; //Will keep track of number of right guesses
      this.numWrong = 0; //Will keep track of number of wrong guesses
      //this.triesUsed = 0;
      //this.numTries1 = 0;
      //this.numTriesUsed = this.add.text(20, 20, 'Num Tries: 3', {fontSize: '40px', fill: "#ffffff"});


      //March 3
      // Will trigger when a piece of trash is over a garbage can
       this.trashGroup = this.physics.add.group();
        this.trashGroup.add(this.trash1);
        this.trashGroup.add(this.trash2);
        this.trashGroup.add(this.trash3);
        this.trashGroup.add(this.trash4);
        this.trashGroup.add(this.trash5);

      this.trashCanGroup = this.physics.add.group();
        this.trashCanGroup.add(this.trashCan1);
        this.trashCanGroup.add(this.trashCan2);
        this.trashCanGroup.add(this.trashCan3);
        this.trashCanGroup.add(this.trashCan4);
        this.trashCanGroup.add(this.trashCan5);
        
      this.physics.add.overlap(
        this.trashGroup,
        this.trashCanGroup,
        this.putInTrash,
        null,
        this
      );
      
    
      /*this.testText = this.add.text(this.trash.x, this.trash.y, '3+4', {
        fontSize: '15px', fill: '#ffffff'
      }); //Obviously this only attaches text to one piece of trash
          //it would be annoying/time consuming to do this for each and every
          //possible equation that could appear.*/
    
    }


putInTrash(trash, trashCan) {
  // if this can is already solved, ignore
  if (trashCan && trashCan._disabled) return;

  // stop overlap-per-frame spam
  if (trash._lockedOnCan) return;
  trash._lockedOnCan = true;

  // unlock only after leaving all cans
  const unlockWhenLeaving = () => {
    const cans = [this.trashCan1, this.trashCan2, this.trashCan3, this.trashCan4, this.trashCan5]
      .filter((c) => c && c.active);

    const stillOverAny = cans.some((c) => this.physics.overlap(trash, c));

    if (!stillOverAny) {
      trash._lockedOnCan = false;

      // restore tint if not dragging
      if (trash && trash.active && trash.trashMath && !trash._dragging) {
        trash.trashMath.clearTint();
      }
    } else {
      this.time.delayedCall(100, unlockWhenLeaving);
    }
  };

  // Check if the trash can is the correct one
  if (trash.answer === trashCan.answer) {
    this.correct?.destroy();
    this.correct = this.add.text(30, 200, "That is Correct!", {
      fontSize: "80px",
      fill: "#ffffff",
    });

    // destorying trash, and trash can
    if (trashCan.markCorrect) trashCan.markCorrect();

    // remove trash
    trash.destroy();
    trashCan.destroy();

    this.numCorrect += 1;
    this.time.delayedCall(550, this.onCorrect, [], this);

    if (this.numCorrect === 5) {
      // keep hidden during play; toast shows final number
      this.time.delayedCall(550, this.onFinish, [], this);
    }

    return;
  }

  // Wrong (count once)
  this.numWrong += 1;

  // keep hidden, but update stored number for toast

  if(trash === this.trash1){
    this.numGuessesPerAnswer[0].numGuess++;
  }
  else if(trash === this.trash2){
    this.numGuessesPerAnswer[1].numGuess++;
  }
  else if(trash === this.trash3){
    this.numGuessesPerAnswer[2].numGuess++;
  }
  else if(trash == this.trash4){
    this.numGuessesPerAnswer[3].numGuess++;
  }
  else if(trash == this.trash5){
    this.numGuessesPerAnswer[4].numGuess++;
  };

  this.wrongText?.destroy();
  this.wrongText = this.add.text(30, 200, "Try again!", {
    fontSize: "80px",
    fill: "#ffffff",
  });

  this.time.delayedCall(550, () => this.wrongText?.destroy());
  this.triesUsed += 1;

  // allow another wrong count only after leaving cans
  unlockWhenLeaving();
}

    onCorrect()
    {
      this.correct.destroy();
    };


    onFinish()
    {
      this.endGame = this.add.text(235, 150, 'Congradulations! You Finished!', {fontSize: '60px', fill: '#ffffff'});
      this.guessesQuestion1 = this.add.text(250, 300, 'Number of Wrong Guesses for ' + this.trash1.question + " has " +  this.trash1.answer + " : " + this.numGuessesPerAnswer[0].numGuess, {fontSize: '40px', fill: '#ffffff'});
      this.guessesQuestion2 = this.add.text(250, 400, 'Number of Wrong Guesses for ' + this.trash2.question + " has " +  this.trash2.answer + " : "  + this.numGuessesPerAnswer[1].numGuess, {fontSize: '40px', fill: '#ffffff'});
      this.guessesQuestion3 = this.add.text(250, 500, 'Number of Wrong Guesses for ' + this.trash3.question + " has " +  this.trash3.answer + " : "  + this.numGuessesPerAnswer[2].numGuess, {fontSize: '40px', fill: '#ffffff'});
      this.guessesQuestion4 = this.add.text(250, 600, 'Number of Wrong Guesses for ' + this.trash4.question + " has " +  this.trash4.answer + " : "  + this.numGuessesPerAnswer[3].numGuess, {fontSize: '40px', fill: '#ffffff'});
      this.guessesQuestion5 = this.add.text(250, 700, 'Number of Wrong Guesses for ' + this.trash5.question + " has " +  this.trash5.answer + " : "  + this.numGuessesPerAnswer[4].numGuess, {fontSize: '40px', fill: '#ffffff'});
    };
}